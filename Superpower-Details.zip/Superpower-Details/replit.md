# Daniel Caesar - Superpower Website

## Overview
A dark-themed one-page website showcasing Daniel Caesar's "Superpower" song with elegant design, smooth animations, and a sophisticated black/gold color palette.

## Project Structure
```
/
├── index.html      # Main HTML structure
├── styles.css      # All styling with CSS variables
├── script.js       # JavaScript for animations and interactions
├── .gitignore      # Python gitignore
└── replit.md       # This file
```

## Features
- Hero section with album art placeholder and song title
- Credits section with production details
- Lyrics display section
- Smooth scroll navigation
- Fade-in animations on scroll
- Floating particle effects
- Responsive design for all devices

## Tech Stack
- HTML5
- CSS3 (Custom properties, Flexbox, Grid, Animations)
- Vanilla JavaScript
- Python 3.11 (Simple HTTP Server)

## Color Palette
- Primary Black: #0a0a0a
- Secondary Black: #111111
- Card Black: #141414
- Accent Gold: #d4af37
- Text White: #ffffff
- Text Gray: #a0a0a0

## Running the Project
The website runs on port 5000 using Python's built-in HTTP server.

## Recent Changes
- December 5, 2025: Initial creation of the website
